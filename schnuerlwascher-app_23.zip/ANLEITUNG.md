# Angeltagebuch – Einrichtungsanleitung

## Übersicht
Die App besteht aus 3 Dateien:
- `angeltagebuch.html` – die App selbst
- `manifest.json` – für die Smartphone-Installation
- `sw.js` – für Offline-Unterstützung

Für geteilte Daten brauchst du **Firebase** (kostenlos) und **Netlify** (kostenlos).
Zeitaufwand: ca. 15–20 Minuten, kein Programmierwissen nötig.

---

## Schritt 1: Firebase-Projekt anlegen

1. Gehe auf https://console.firebase.google.com
2. Melde dich mit deinem Google-Konto an
3. Klicke auf „Projekt hinzufügen"
4. Projektname: z.B. `angeltagebuch`
5. Google Analytics deaktivieren → „Projekt erstellen"
6. Warte bis fertig, dann „Weiter"

---

## Schritt 2: Web-App registrieren

1. Im Dashboard: Klicke auf das </> Symbol (Web-App hinzufügen)
2. App-Nickname: z.B. `Angeltagebuch`
3. Firebase Hosting: NICHT anhaken
4. „App registrieren"
5. Du siehst deinen firebaseConfig-Block – Fenster offen lassen!

---

## Schritt 3: Realtime Database aktivieren

1. Linkes Menü: „Erstellen" → „Realtime Database"
2. „Datenbank erstellen"
3. Standort: „europe-west1 (Belgien)" → „Weiter"
4. „Im Testmodus starten" → „Aktivieren"

WICHTIG nach 30 Tagen: Gehe zu Realtime Database → Regeln und setze:
{ "rules": { ".read": true, ".write": true } }

---

## Schritt 4: App konfigurieren

Öffne angeltagebuch.html in einem Texteditor (Notepad/TextEdit).
Suche den Abschnitt mit DEIN_API_KEY und ersetze alle 7 Platzhalter
mit deinen Firebase-Werten aus Schritt 2. Datei speichern.

---

## Schritt 5: App online stellen (Netlify)

1. Gehe auf https://netlify.com → kostenlos registrieren
2. „Add new site" → „Deploy manually"
3. Alle 3 Dateien in das Upload-Feld ziehen
4. Du bekommst eine URL wie: https://dein-name.netlify.app
5. Diese URL an alle Fischer schicken!

---

## Schritt 6: App auf Smartphones installieren

ANDROID (Chrome):
Menü (3 Punkte) → „Zum Startbildschirm hinzufügen"

IPHONE (Safari – nicht Chrome!):
Teilen-Symbol → „Zum Home-Bildschirm" → „Hinzufügen"

---

Fertig! Alle Fischer sehen jetzt dieselben Daten in Echtzeit.
